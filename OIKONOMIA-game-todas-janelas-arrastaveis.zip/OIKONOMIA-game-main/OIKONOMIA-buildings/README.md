# 🏗️ OIKONOMIA — Biblioteca de Prédios & Construções

Pasta central para organizar todas as **imagens isométricas 2.5D** dos prédios do simulador econômico OIKONOMIA.

---

## 📂 Estrutura de Pastas

### 🏠 **`/residencial`**
Casas, apartamentos, edifícios residenciais, condomínios.
- Casa simples (1-2 pavimentos)
- Casa de luxo / mansão
- Prédio de apartamentos
- Favela / ocupação irregular

### 🏭 **`/industrial`**
Fábricas, minas, usinas, depósitos de manufatura.
- Fábrica de alimentos
- Siderúrgica / extração de minério
- Fábrica de eletrônicos
- Fábrica têxtil
- Refinaria de petróleo
- Fábrica de automóveis
- Celulose / madeira
- Armazém / galpão industrial

### 🛒 **`/comercial`**
Lojas, supermercados, shoppings, restaurantes, serviços.
- Supermercado
- Loja de roupas / vestuário
- Loja de eletrônicos
- Concessionária de carros
- Restaurante / bar
- Hotel
- Shopping center
- Banco / órgão financeiro
- Consultório médico / farmácia

### 🌾 **`/agricultura`**
Fazendas, silos, estufas, celeiros, campos.
- Fazenda de trigo / grãos
- Fazenda de gado / pecuária
- Fazenda de algodão
- Pomar / plantação de frutíferas
- Silo de armazenamento
- Estufa agrícola
- Celeiro / depósito agrícola

### 🚢 **`/portuario`**
Terminais portuários, cais, docas, piers, armazéns costeiros.
- Terminal de contêineres
- Cais de carga / descarga
- Armazém portuário
- Bombas de combustível (posto de gasolina marítima)
- Farol / sinalização

### 🏛️ **`/utilidade_publica`**
Edifícios públicos, governança, infraestrutura essencial.
- Prefeitura / câmara municipal
- Polícia / segurança
- Corpo de bombeiros
- Hospital / emergência
- Escola / universidade
- Parque / espaço público
- Estação de energia / subestação
- Estação de tratamento de água
- Delegacia / cadeia

### 🎨 **`/decoracao`**
Elementos decorativos, parques, monumentos, pequenos acessórios.
- Árvores / vegetação
- Monumentos / estátuas
- Praça / jardim público
- Fonte decorativa
- Placa de sinalização
- Bancos / mobiliário urbano

### 🛣️ **`/vias`**
Infraestrutura de transporte, estradas, pontes, viadutos.
- Rodovia de pista dupla (horizontal)
- Rodovia de pista dupla (vertical)
- Rodovia de pista dupla (curvas)
- Ponte / viaduto
- Linha férrea / trem
- Estação de trem
- Estação de ônibus
- Rotatória / cruzamento

---

## 🎨 **Formato de Imagens Recomendado**

- **Formato**: PNG 32-bit (transparência RGBA)
- **Estilo**: Isométrico 2.5D (ângulo 30°-45°)
- **Resolução**: 64×64 a 256×256 pixels (depende do nível de detalhe)
- **Propósito**: Compatível com tileset do Tiled e renderização em HTML5 Canvas

### Exemplo de Nomeação
```
residencial/
  ├── casa_simples_lv1.png
  ├── casa_simples_lv2.png
  ├── casa_luxo_lv1.png
  ├── predio_apartamentos_lv1.png
  └── predio_apartamentos_lv2.png

industrial/
  ├── fabrica_alimentos_lv1.png
  ├── siderurgica_lv1.png
  ├── fabrica_eletronicos_lv2.png
  └── armazem_galpao.png
```

---

## 🔗 **Integração com OIKONOMIA**

As imagens podem ser:
1. **Compiladas no tileset.png** e referenciadas no `map_data.js`
2. **Carregadas dinamicamente** via JavaScript no cliente
3. **Exportadas para Tiled** e regeneradas via `export_map_to_js.ps1`

---

## ✅ Checklist de Prédios Prioritários

- [ ] Fazenda (trigo, gado, algodão)
- [ ] Fábrica (alimentos, têxtil, siderúrgica)
- [ ] Loja (supermercado, eletrônicos, vestuário)
- [ ] Concessionária (veículos)
- [ ] Mina / extração
- [ ] Terminal portuário
- [ ] Casa / residencial
- [ ] Hotel / hospedagem
- [ ] Estação de energia
- [ ] Estradas / vias

---

**Boa sorte com a criação das imagens, Keko!** 🚀
